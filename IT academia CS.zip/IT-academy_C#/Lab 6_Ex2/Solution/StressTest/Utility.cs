﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StressTest
{
    static class Utility
    {
        public static Random Rand = new Random();
    }
}
